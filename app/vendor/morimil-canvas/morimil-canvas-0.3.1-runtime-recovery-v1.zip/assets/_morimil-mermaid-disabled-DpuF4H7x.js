async function r(){throw new Error("Mermaid is disabled in Morimil Canvas")}export{r as parseMermaidToExcalidraw};
